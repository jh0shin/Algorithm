# 2022 Kakao blind recruitment

2022년 kakao blind recruitment 2차 코딩테스트 application입니다.

## Version
- Python 3.8.8
- Requests 2.25.1